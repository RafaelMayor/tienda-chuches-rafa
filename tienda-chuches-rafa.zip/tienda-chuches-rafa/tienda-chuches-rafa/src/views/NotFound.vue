<template>
    <div class="notfound-container">
      <h1>404 - Página no encontrada</h1>
      <router-link to="/" class="btn btn-pink">Volver al inicio</router-link>
    </div>
  </template>
  
  <style scoped>
  .notfound-container {
    text-align: center;
    padding: 50px;
  }
  .btn-pink {
    background-color: #ff66b2;
    color: white;
  }
  </style>
  